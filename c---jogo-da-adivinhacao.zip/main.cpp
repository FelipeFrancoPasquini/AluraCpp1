#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{
    cout << "----------------------------------------------" << endl;
    cout << "|Curso de C++: Conhecendo a linguagem e a STL|" << endl;
    cout << "----------------------------------------------" << endl;
    
    bool nao_acertou = true;
    int tentativas_utilizadas = 0, tentativas_disponiveis;
    double pontos = 1000.0;
    char dificuldade;
    
    srand(time(NULL));
    const int NUMERO_SECRETO = (rand() % 100);  
    cout << "O número secreto é: " << NUMERO_SECRETO << endl;
    
    cout << "Em qual nível de dificuldade deseja jogar?" << endl;
    cout << "Digite (F) para Fácil, (M) para Médio e (D) para Difícil." << endl;
    cin >> dificuldade;
    
    if (dificuldade == 'F'){
        
        tentativas_disponiveis = 20;
        
    }else if (dificuldade == 'M'){
        
        tentativas_disponiveis = 15;
        
    }else if (dificuldade == 'D'){
        
        tentativas_disponiveis = 10;
        
    }else{
        
        cout << "Por favor, insira 'F', 'M' ou 'D' para selecionar a dificuldade." << endl;
        cout << "Fim de jogo." << endl;
        
        return 0;
        
    }
    cout << "Você terá " << tentativas_disponiveis << " tentativas para acertar o número secreto." << endl;
    
    for (tentativas_utilizadas = 1; tentativas_utilizadas <= tentativas_disponiveis; tentativas_utilizadas++){
        
        int chute;
        bool maior, menor, acertou;
        
        cout << "Tentativa número: " << tentativas_utilizadas << endl;
        cout << "Qual seu chute?" << endl;
        cin >> chute;
        
        double pontos_perdidos = abs(chute - NUMERO_SECRETO)/2.0;
        pontos = (pontos - pontos_perdidos);
        
        menor = (chute < NUMERO_SECRETO);
        maior = (chute > NUMERO_SECRETO);
        acertou = (chute == NUMERO_SECRETO);
        
        if (menor){
            
            cout << "O número " << chute << " está abaixo do número secreto." << endl;
            
        }else if (maior){
            
            cout << "O número " << chute << " está acima do número secreto." << endl;
            
        }else{
            
            cout << "Parabéns! Você adivinhou o número secreto utilizando " << tentativas_utilizadas << " tentativas." << endl;
            
            cout.precision(2);
            cout << fixed;
            cout << "Sua pontuação foi de " << pontos << " pontos." << endl;
            
            nao_acertou = false;
            
            break;
            
        }
        
    }
    
    if (nao_acertou){
        
        cout << "Você não acertou o número secreto em " << tentativas_disponiveis << " tentativas." << endl;
        cout << "Tente novamente reiniciando o programa." << endl;
        
    }
    
    cout << "Fim de jogo." << endl;

    return 0;
    
}